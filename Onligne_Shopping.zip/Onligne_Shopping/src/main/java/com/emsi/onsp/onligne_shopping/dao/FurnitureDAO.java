package com.emsi.onsp.onligne_shopping.dao;

import com.emsi.onsp.onligne_shopping.model.FurnitureProduct;
import com.emsi.onsp.onligne_shopping.config.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;

public class FurnitureDAO {

    public List<FurnitureProduct> getAll() {
        Session s = HibernateUtil.getSessionFactory().openSession();
        List<FurnitureProduct> list = s.createQuery("from FurnitureProduct", FurnitureProduct.class).list();
        s.close();
        return list;
    }

    public void save(FurnitureProduct p) {
        Session s = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = s.beginTransaction();
        s.persist(p);
        tx.commit();
        s.close();
    }

    public void update(FurnitureProduct p) {
        Session s = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = s.beginTransaction();
        s.merge(p);
        tx.commit();
        s.close();
    }

    public void delete(FurnitureProduct p) {
        Session s = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = s.beginTransaction();
        s.remove(s.merge(p));
        tx.commit();
        s.close();
    }
}
