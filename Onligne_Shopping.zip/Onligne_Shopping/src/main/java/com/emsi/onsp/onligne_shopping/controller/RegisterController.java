package com.emsi.onsp.onligne_shopping.controller;

import com.emsi.onsp.onligne_shopping.ShoppingApplication;
import com.emsi.onsp.onligne_shopping.utils.UserSession;
import com.emsi.onsp.onligne_shopping.dao.UserDAO;
import com.emsi.onsp.onligne_shopping.model.User;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class RegisterController {

    @FXML
    private TextField nameField;

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private PasswordField confirmPasswordField;

    private UserDAO userDAO;

    public RegisterController() {
        this.userDAO = new UserDAO();
    }

    @FXML
    protected void onRegisterButtonClick() {
        String name = nameField.getText();
        String email = emailField.getText();
        String password = passwordField.getText();
        String confirmPassword = confirmPasswordField.getText();

        if (name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields");
            return;
        }

        if (!password.equals(confirmPassword)) {
            showAlert(Alert.AlertType.ERROR, "Error", "Passwords do not match");
            return;
        }

        if (userDAO.findUserByEmail(email) != null) {
            showAlert(Alert.AlertType.ERROR, "Error", "Email already registered");
            return;
        }

        User newUser = new User(name, email, password, "CUSTOMER");
        userDAO.save(newUser);


        // Auto-login after registration
        User registeredUser = userDAO.findUserByEmail(email);
        if (registeredUser != null) {
            UserSession.getInstance().setCurrentUser(registeredUser);
            showAlert(Alert.AlertType.INFORMATION, "Success", "Registration successful! Logging you in...");
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(ShoppingApplication.class.getResource("products.fxml"));
                Scene scene = new Scene(fxmlLoader.load(), 800, 600);
                Stage stage = (Stage) emailField.getScene().getWindow();
                stage.setTitle("Online Shopping - Products");
                stage.setScene(scene);
            } catch (IOException e) {
                e.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to load products page.");
            }
        } else {
            showAlert(Alert.AlertType.INFORMATION, "Success", "Registration successful! Please login.");
            onLoginLinkClick();
        }
    }

    @FXML
    protected void onLoginLinkClick() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(ShoppingApplication.class.getResource("login.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 400, 500);
            Stage stage = (Stage) emailField.getScene().getWindow();
            stage.setTitle("Online Shopping - Login");
            stage.setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
