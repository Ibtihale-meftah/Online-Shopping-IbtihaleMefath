package com.emsi.onsp.onligne_shopping.dao;

import com.emsi.onsp.onligne_shopping.config.HibernateUtil;
import com.emsi.onsp.onligne_shopping.model.RealEstateProduct;
import org.hibernate.Session;
import java.util.List;

public class RealEstateProductDAO {

    public List<RealEstateProduct> getAll() {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            return s.createQuery("from RealEstateProduct", RealEstateProduct.class).list();
        }
    }
}
