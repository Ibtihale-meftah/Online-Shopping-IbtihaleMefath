package com.emsi.onsp.onligne_shopping.model;

public class CartItem {
    private FurnitureProduct product;
    private int quantity;

    public CartItem() {
    }

    public CartItem(FurnitureProduct product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }

    public FurnitureProduct getProduct() {
        return product;
    }

    public void setProduct(FurnitureProduct product) {
        this.product = product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getTotal() {
        return product.getPrice() * quantity;
    }
}
