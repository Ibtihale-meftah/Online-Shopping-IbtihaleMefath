package com.emsi.onsp.onligne_shopping.controller;

import com.emsi.onsp.onligne_shopping.dao.FurnitureDAO;
import com.emsi.onsp.onligne_shopping.model.FurnitureProduct;
import com.emsi.onsp.onligne_shopping.utils.CartManager;
import com.emsi.onsp.onligne_shopping.utils.UserSession;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class ProductsController implements Initializable {

    @FXML
    private Label welcomeLabel;
    @FXML
    private ScrollPane scrollPane;
    @FXML
    private GridPane productGrid;

    private FurnitureDAO productDAO = new FurnitureDAO();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        if (UserSession.getInstance().getCurrentUser() != null) {
            welcomeLabel.setText("Welcome, " + UserSession.getInstance().getCurrentUser().getName());
        }
        loadProducts();
    }

    private void loadProducts() {
        productGrid.getChildren().clear();
        List<FurnitureProduct> products = productDAO.getAll();
        int column = 0;
        int row = 1;

        for (FurnitureProduct product : products) {
            VBox productCard = createCard(product);
            productGrid.add(productCard, column++, row);
            // 3 columns grid
            if (column == 3) {
                column = 0;
                row++;
            }
        }
    }

    private VBox createCard(FurnitureProduct product) {
        VBox card = new VBox(10);
        card.setAlignment(Pos.CENTER);
        card.setPadding(new Insets(15));
        card.getStyleClass().add("product-card"); // Will be in CSS
        // Inline fail-safe style
        card.setStyle(
                "-fx-background-color: white; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 5, 0, 0, 0); -fx-background-radius: 5;");
        card.setPrefWidth(220);

        ImageView imageView = new ImageView();
        // Simple image placeholder logic
        try {
            String imagePath = product.getImage();
            if (imagePath != null && !imagePath.isEmpty()) {
                // Try as resource then as URL? For now assume resource relative or URL
                // Ideally this handles both. Simplified for now.
                if (!imagePath.startsWith("http")) {
                    // Local resource?
                    // imagePath = "/com/emsi/onsp/onligne_shopping/images/" + imagePath;
                }
                imageView.setImage(new Image(imagePath, 200, 150, true, true, true));
            }
        } catch (Exception e) {
            // ignore
        }

        if (imageView.getImage() == null) {
            // Default place holder
            // imageView.setImage(new Image(...));
        }
        imageView.setFitHeight(150);
        imageView.setFitWidth(200);

        Label nameLbl = new Label(product.getName());
        nameLbl.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");

        Label priceLbl = new Label(String.format("%.2f $", product.getPrice()));
        priceLbl.setStyle("-fx-text-fill: #007bff; -fx-font-weight: bold;");

        Label stockLbl = new Label("Stock: " + product.getStock());

        Button addBtn = new Button("Add to Cart");
        addBtn.setOnAction(e -> {
            CartManager.add(product);
            showAlert("Added", product.getName() + " added to cart.");
        });

        card.getChildren().addAll(imageView, nameLbl, priceLbl, stockLbl, addBtn);
        return card;
    }

    @FXML
    public void onCartButtonClick() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(
                    getClass().getResource("/com/emsi/onsp/onligne_shopping/cart_view.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            Stage stage = (Stage) scrollPane.getScene().getWindow();
            stage.setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void onLogoutButtonClick() {
        UserSession.getInstance().logout();
        CartManager.clear();
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(
                    getClass().getResource("/com/emsi/onsp/onligne_shopping/login.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            Stage stage = (Stage) scrollPane.getScene().getWindow();
            stage.setTitle("Login");
            stage.setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.show();
    }
}
