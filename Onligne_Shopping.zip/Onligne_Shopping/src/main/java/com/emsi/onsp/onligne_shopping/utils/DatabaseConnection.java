package com.emsi.onsp.onligne_shopping.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/onlineshopping_db";
    private static final String USER = "root";
    private static final String PASSWORD = ""; // Empty password as per common default, user can change

    private static Connection connection;

    private DatabaseConnection() {
    }

    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // In a real app we might want to show an alert to the user here
            System.err.println("Database connection failed: " + e.getMessage());
        }
        return connection;
    }
}
