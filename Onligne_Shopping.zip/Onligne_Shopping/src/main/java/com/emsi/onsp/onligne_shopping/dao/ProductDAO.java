package com.emsi.onsp.onligne_shopping.dao;

import com.emsi.onsp.onligne_shopping.config.HibernateUtil;
import com.emsi.onsp.onligne_shopping.model.Product;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

    public List<Product> getAll() {
        List<Product> products = new ArrayList<>();
        String sql = "SELECT id, name, price, stock FROM products";

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            List<Object[]> rows = session.createNativeQuery(sql).getResultList();

            for (Object[] row : rows) {
                Product p = new Product();
                p.setId(((Number) row[0]).intValue());
                p.setName((String) row[1]);
                p.setPrice(((Number) row[2]).doubleValue());
                p.setStock(((Number) row[3]).intValue());
                products.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return products;
    }

    // Methods needed to keep controller compiling/working (simulation or basic
    // impl)
    public void save(Product p) {
        String sql = "INSERT INTO products (name, price, stock) VALUES (:name, :price, :stock)";
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();
            session.createNativeQuery(sql)
                    .setParameter("name", p.getName())
                    .setParameter("price", p.getPrice())
                    .setParameter("stock", p.getStock())
                    .executeUpdate();
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void update(Product p) {
        // Simplified update for demo
        String sql = "UPDATE products SET name=:name, price=:price, stock=:stock WHERE id=:id";
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();
            session.createNativeQuery(sql)
                    .setParameter("name", p.getName())
                    .setParameter("price", p.getPrice())
                    .setParameter("stock", p.getStock())
                    .setParameter("id", p.getId())
                    .executeUpdate();
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void delete(Product p) {
        String sql = "DELETE FROM products WHERE id=:id";
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();
            session.createNativeQuery(sql)
                    .setParameter("id", p.getId())
                    .executeUpdate();
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
