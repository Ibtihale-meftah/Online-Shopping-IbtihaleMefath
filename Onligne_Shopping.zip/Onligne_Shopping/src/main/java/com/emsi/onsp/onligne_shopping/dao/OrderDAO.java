package com.emsi.onsp.onligne_shopping.dao;

import com.emsi.onsp.onligne_shopping.model.Order;
import com.emsi.onsp.onligne_shopping.model.OrderItem;
import com.emsi.onsp.onligne_shopping.config.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class OrderDAO {

    public void saveOrder(Order order, java.util.List<OrderItem> items) {
        Session s = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = s.beginTransaction();

        try {
            s.persist(order);
            // After persisting order, it should have an ID generated if using IDENTITY

            for (OrderItem item : items) {
                item.setOrderId(order.getId());
                s.persist(item);
            }

            tx.commit();
        } catch (Exception e) {
            if (tx != null)
                tx.rollback();
            e.printStackTrace();
        } finally {
            s.close();
        }
    }
}
