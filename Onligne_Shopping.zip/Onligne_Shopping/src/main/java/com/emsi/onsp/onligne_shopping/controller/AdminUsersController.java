package com.emsi.onsp.onligne_shopping.controller;

import com.emsi.onsp.onligne_shopping.dao.UserDAO;
import com.emsi.onsp.onligne_shopping.model.User;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.util.Callback;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class AdminUsersController {

    @FXML
    private TableView<User> tableUsers;
    @FXML
    private TableColumn<User, Integer> colId;
    @FXML
    private TableColumn<User, String> colName;
    @FXML
    private TableColumn<User, String> colEmail;
    @FXML
    private TableColumn<User, String> colRole;
    @FXML
    private TableColumn<User, Void> colAction;

    @FXML
    private TextField txtName;
    @FXML
    private TextField txtEmail;
    @FXML
    private PasswordField txtPassword;
    @FXML
    private ComboBox<String> comboRole;

    private UserDAO userDAO = new UserDAO();

    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colRole.setCellValueFactory(new PropertyValueFactory<>("role"));

        comboRole.setItems(FXCollections.observableArrayList("ADMIN", "USER"));
        comboRole.getSelectionModel().select("USER");

        addDeleteButton();
        loadUsers();

        tableUsers.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                populateFields(newSelection);
            }
        });
    }

    private void loadUsers() {
        tableUsers.getItems().setAll(userDAO.getAll());
    }

    private void populateFields(User user) {
        txtName.setText(user.getName());
        txtEmail.setText(user.getEmail());
        txtPassword.setText(user.getPassword());
        comboRole.setValue(user.getRole());
    }

    @FXML
    public void onAdd() {
        String name = txtName.getText();
        String email = txtEmail.getText();
        String password = txtPassword.getText();
        String role = comboRole.getValue();

        if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
            showAlert("Error", "All fields are required.");
            return;
        }

        User u = new User(name, email, password, role);
        userDAO.save(u);
        loadUsers();
        clearFields();
    }

    @FXML
    public void onUpdate() {
        User selected = tableUsers.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Error", "No user selected.");
            return;
        }

        selected.setName(txtName.getText());
        selected.setEmail(txtEmail.getText());
        selected.setPassword(txtPassword.getText());
        selected.setRole(comboRole.getValue());

        userDAO.update(selected);
        loadUsers();
        clearFields();
    }

    private void addDeleteButton() {
        Callback<TableColumn<User, Void>, TableCell<User, Void>> cellFactory = new Callback<>() {
            @Override
            public TableCell<User, Void> call(final TableColumn<User, Void> param) {
                final TableCell<User, Void> cell = new TableCell<>() {
                    private final Button btn = new Button("Delete");

                    {
                        btn.getStyleClass().add("button-danger");
                        btn.setOnAction((event) -> {
                            User data = getTableView().getItems().get(getIndex());
                            if ("ADMIN".equals(data.getRole()) && data.getId() == 1) { // Basic protection for main
                                                                                       // admin?
                                // Or check if it is current user, but we don't track session yet easily here
                                // For now, let's just ask confirmation
                            }
                            userDAO.delete(data);
                            loadUsers();
                        });
                    }

                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(btn);
                        }
                    }
                };
                return cell;
            }
        };
        colAction.setCellFactory(cellFactory);
    }

    @FXML
    public void onBack() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(
                getClass().getResource("/com/emsi/onsp/onligne_shopping/admin_dashboard.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) tableUsers.getScene().getWindow();
        stage.setScene(scene);
    }

    private void clearFields() {
        txtName.clear();
        txtEmail.clear();
        txtPassword.clear();
        comboRole.getSelectionModel().select("USER");
        tableUsers.getSelectionModel().clearSelection();
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
