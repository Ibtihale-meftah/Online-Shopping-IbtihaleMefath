package com.emsi.onsp.onligne_shopping.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import java.io.IOException;

public class AdminDashboardController {

    @FXML
    private Button btnUsers;
    @FXML
    private Button btnProducts;
    @FXML
    private Button btnLogout;

    @FXML
    public void onUsersClick() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(
                getClass().getResource("/com/emsi/onsp/onligne_shopping/admin_users.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) btnUsers.getScene().getWindow();
        stage.setScene(scene);
    }

    @FXML
    public void onProductsClick() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(
                getClass().getResource("/com/emsi/onsp/onligne_shopping/admin_products.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) btnProducts.getScene().getWindow();
        stage.setScene(scene);
    }

    @FXML
    public void onLogoutClick() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/emsi/onsp/onligne_shopping/login.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) btnLogout.getScene().getWindow();
        stage.setScene(scene);
    }
}
