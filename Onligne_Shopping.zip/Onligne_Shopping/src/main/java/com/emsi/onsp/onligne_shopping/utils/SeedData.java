package com.emsi.onsp.onligne_shopping.utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SeedData {
    public static void seed() {
        Connection conn = DatabaseConnection.getConnection();
        if (conn == null) {
            System.err.println("Could not connect to database.");
            return;
        }

        try {
            // Check if products already exist
            String countSql = "SELECT COUNT(*) FROM products";
            try (PreparedStatement countStmt = conn.prepareStatement(countSql);
                    var rs = countStmt.executeQuery()) {
                if (rs.next() && rs.getInt(1) > 0) {
                    System.out.println("Products already exist. Skipping seed.");
                    return;
                }
            }

            System.out.println("Seeding products...");
            String sql = "INSERT INTO products (name, price, description, image) VALUES (?, ?, ?, ?)";

            Object[][] products = {
                    { "Smartphone Galaxy S21", 799.99, "Latest generation smartphone with 5G.", "s21.png" },
                    { "Laptop Pro 15", 1299.50, "High performance laptop for professionals.", "laptop.png" },
                    { "Wireless Headphones", 199.99, "Noise cancelling over-ear headphones.", "headphones.png" },
                    { "Smart Watch Series 6", 399.00, "Fitness tracker and health monitor.", "watch.png" },
                    { "4K Monitor 27-inch", 349.99, "Ultra HD monitor for crisp visuals.", "monitor.png" },
                    { "Mechanical Keyboard", 89.99, "RGB mechanical keyboard with blue switches.", "keyboard.png" },
                    { "Gaming Mouse", 49.99, "High DPI gaming mouse.", "mouse.png" },
                    { "External SSD 1TB", 129.99, "Fast portable storage.", "ssd.png" },
                    { "USB-C Hub", 39.99, "Multi-port adapter for laptops.", "hub.png" },
                    { "Webcam 1080p", 59.99, "Full HD webcam for streaming.", "webcam.png" }
            };

            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                for (Object[] p : products) {
                    pstmt.setString(1, (String) p[0]);
                    pstmt.setDouble(2, (Double) p[1]);
                    pstmt.setString(3, (String) p[2]);
                    pstmt.setString(4, (String) p[3]);
                    pstmt.addBatch();
                }
                int[] result = pstmt.executeBatch();
                System.out.println(result.length + " products added successfully!");
            }
        } catch (SQLException e) {
            System.err.println("Error seeding data:");
            e.printStackTrace();
        }
    }
}
