package com.emsi.onsp.onligne_shopping.controller;

import com.emsi.onsp.onligne_shopping.dao.OrderDAO;
import com.emsi.onsp.onligne_shopping.model.CartItem;
import com.emsi.onsp.onligne_shopping.model.Order;
import com.emsi.onsp.onligne_shopping.model.OrderItem;
import com.emsi.onsp.onligne_shopping.model.User;
import com.emsi.onsp.onligne_shopping.utils.CartManager;
import com.emsi.onsp.onligne_shopping.utils.UserSession;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CartController {

    @FXML
    private VBox cartItemsLayout;
    @FXML
    private Label totalLabel;

    private OrderDAO orderDAO = new OrderDAO();

    @FXML
    public void initialize() {
        renderCart();
        updateTotal();
    }

    private void renderCart() {
        cartItemsLayout.getChildren().clear();
        List<CartItem> items = CartManager.getItems();

        if (items.isEmpty()) {
            cartItemsLayout.getChildren().add(new Label("Your cart is empty"));
            return;
        }

        for (CartItem item : items) {
            HBox row = new HBox(10);
            row.setStyle("-fx-padding: 10; -fx-border-color: #ddd; -fx-border-width: 0 0 1 0;");

            Label nameLbl = new Label(item.getProduct().getName());
            nameLbl.setPrefWidth(200);

            Label priceLbl = new Label(String.format("%.2f $", item.getProduct().getPrice()));
            priceLbl.setPrefWidth(100);

            Label qtyLbl = new Label("x " + item.getQuantity());
            qtyLbl.setPrefWidth(50);

            Label subTotalLbl = new Label(String.format("%.2f $", item.getTotal()));
            subTotalLbl.setPrefWidth(100);

            Button removeBtn = new Button("Remove");
            removeBtn.getStyleClass().add("button-danger");
            removeBtn.setOnAction(e -> {
                CartManager.remove(item);
                renderCart();
                updateTotal();
            });

            row.getChildren().addAll(nameLbl, priceLbl, qtyLbl, subTotalLbl, removeBtn);
            cartItemsLayout.getChildren().add(row);
        }
    }

    private void updateTotal() {
        totalLabel.setText(String.format("Total: %.2f $", CartManager.getTotal()));
    }

    @FXML
    public void onOrder() {
        if (CartManager.getItems().isEmpty()) {
            showAlert("Cart is empty", "Please add items before ordering.");
            return;
        }

        User user = UserSession.getInstance().getCurrentUser();
        if (user == null) {
            showAlert("Login Required", "You must be logged in to order.");
            return;
        }

        double total = CartManager.getTotal();
        Order order = new Order(user.getId(), new Date(), total);

        List<OrderItem> orderItems = new ArrayList<>();
        for (CartItem ci : CartManager.getItems()) {
            orderItems.add(new OrderItem(0, ci.getProduct().getId(), ci.getQuantity(), ci.getProduct().getPrice()));
        }

        orderDAO.saveOrder(order, orderItems);

        // Simulation d'un traitement long (ex: Paiement bancaire)
        new Thread(() -> {
            System.out.println("Thread 2 (Payment): Traitement du paiement en cours pour " + total + " $...");
            try {
                Thread.sleep(3000); // Pause de 3 secondes
                System.out.println("Thread 2 (Payment): Paiement validé pour le client ID " + user.getId());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();

        CartManager.clear();
        renderCart();
        updateTotal();
        showAlert("Success", "Your order has been placed!");
    }

    @FXML
    public void onBack() throws IOException {
        // Navigate back to Products page
        // Assuming there is a products_view.fxml or similar.
        // User request didn't specify filename for products page, but existing project
        // had products.fxml
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/emsi/onsp/onligne_shopping/products.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) totalLabel.getScene().getWindow();
        stage.setScene(scene);
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
