package com.emsi.onsp.onligne_shopping.controller;

import com.emsi.onsp.onligne_shopping.dao.UserDAO;
import com.emsi.onsp.onligne_shopping.model.User;
import com.emsi.onsp.onligne_shopping.utils.UserSession;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    private final UserDAO userDAO = new UserDAO();

    @FXML
    protected void onLoginButtonClick() {

        String email = emailField.getText();
        String password = passwordField.getText();

        if (email == null || email.isBlank() || password == null || password.isBlank()) {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Veuillez saisir l’email et le mot de passe.");
            return;
        }

        User user = userDAO.findUserByEmail(email);

        if (user != null && password.equals(user.getPassword())) {

            UserSession.getInstance().setCurrentUser(user);

            // Simulation d'un traitement en arrière-plan (ex: Audit Log)
            new Thread(() -> {
                System.out.println("Thread 1 (Login): Début de l'enregistrement du log de connexion...");
                try {
                    Thread.sleep(2000); // Pause de 2 secondes
                    System.out.println("Thread 1 (Login): Utilisateur " + user.getEmail() + " connecté avec succès à "
                            + new java.util.Date());
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();

            try {
                String fxmlPath;
                String title;

                if ("ADMIN".equalsIgnoreCase(user.getRole())) {
                    fxmlPath = "/com/emsi/onsp/onligne_shopping/admin_dashboard.fxml";
                    title = "Admin Dashboard";
                } else {
                    fxmlPath = "/com/emsi/onsp/onligne_shopping/products.fxml";
                    title = "Furniture Store";
                }

                FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
                Scene scene = new Scene(loader.load());

                Stage stage = (Stage) emailField.getScene().getWindow();
                stage.setTitle(title);
                stage.setScene(scene);
                stage.show();

            } catch (IOException e) {
                e.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Erreur",
                        "Impossible de charger la page demandée.");
            }

        } else {
            showAlert(Alert.AlertType.ERROR, "Échec de connexion",
                    "Email ou mot de passe incorrect.");
        }
    }

    @FXML
    protected void onRegisterLinkClick() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/emsi/onsp/onligne_shopping/register.fxml"));
            Scene scene = new Scene(loader.load());

            Stage stage = (Stage) emailField.getScene().getWindow();
            stage.setTitle("Register");
            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur",
                    "Impossible d’ouvrir la page d’inscription.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
