package com.emsi.onsp.onligne_shopping.utils;

import com.emsi.onsp.onligne_shopping.model.CartItem;
import com.emsi.onsp.onligne_shopping.model.FurnitureProduct;
import java.util.ArrayList;
import java.util.List;

public class CartManager {
    private static final List<CartItem> cart = new ArrayList<>();

    public static void add(FurnitureProduct p) {
        for (CartItem item : cart) {
            if (item.getProduct().getId() == p.getId()) {
                item.setQuantity(item.getQuantity() + 1);
                return;
            }
        }
        CartItem item = new CartItem();
        item.setProduct(p);
        item.setQuantity(1);
        cart.add(item);
    }

    public static void remove(CartItem item) {
        cart.remove(item);
    }

    public static double getTotal() {
        return cart.stream().mapToDouble(CartItem::getTotal).sum();
    }

    public static List<CartItem> getItems() {
        return cart;
    }

    public static void clear() {
        cart.clear();
    }
}
