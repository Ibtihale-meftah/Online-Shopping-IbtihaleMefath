package com.emsi.onsp.onligne_shopping.model;

import jakarta.persistence.*;

@Entity
@Table(name = "real_estate_products")
public class RealEstateProduct {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String title;
    private String type;
    private String city;
    private String address;
    private int surface_m2;
    private int rooms;
    private double price;
    private String status;

    @Column(length = 1000)
    private String description;

    private String image;

    // Constructors
    public RealEstateProduct() {
    }

    public RealEstateProduct(String title, String type, String city, String address, int surface_m2, int rooms,
            double price, String status, String description, String image) {
        this.title = title;
        this.type = type;
        this.city = city;
        this.address = address;
        this.surface_m2 = surface_m2;
        this.rooms = rooms;
        this.price = price;
        this.status = status;
        this.description = description;
        this.image = image;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getSurface_m2() {
        return surface_m2;
    }

    public void setSurface_m2(int surface_m2) {
        this.surface_m2 = surface_m2;
    }

    public int getRooms() {
        return rooms;
    }

    public void setRooms(int rooms) {
        this.rooms = rooms;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
