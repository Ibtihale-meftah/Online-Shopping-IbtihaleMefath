package com.emsi.onsp.onligne_shopping.controller;

import com.emsi.onsp.onligne_shopping.dao.ProductDAO;
import com.emsi.onsp.onligne_shopping.model.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Callback;
import java.io.IOException;

public class AdminProductsController {

    @FXML
    private TableView<Product> tableProducts; // Renamed to match user variable 'productTable' if preferred, but keeping
                                              // FXML naming consistent likely safer. Wait, user said `productTable` in
                                              // snippet but my FXML probably has `tableProducts`. I will check FXML or
                                              // stick to `tableProducts` if existing. User said "Configure les
                                              // colonnes... Dans ProductManagementController". This is
                                              // AdminProductsController. I will stick to existing variable naming logic
                                              // if possible or update FXML. Existing FXML typically binds by fx:id.
    // Existing code had: private TableView<FurnitureProduct> tableProducts;
    // User snippet: private TableView<Product> productTable;
    // I should probably check the FXML to see what the fx:id is.
    // If I cannot check FXML easily, I will rename it 'tableProducts' to match
    // previous controller state, implying FXML uses 'tableProducts'. The user's
    // snippet might be generic.
    // I will use `tableProducts` to minimize FXML breaking risk.

    @FXML
    private TableColumn<Product, Integer> colId;
    @FXML
    private TableColumn<Product, String> colName;
    @FXML
    private TableColumn<Product, Double> colPrice;
    @FXML
    private TableColumn<Product, Integer> colStock; // Existing was colStock?
    @FXML
    private TableColumn<Product, Void> colAction;

    @FXML
    private TextField txtName;
    @FXML
    private TextField txtPrice;
    @FXML
    private TextArea txtDescription;
    @FXML
    private TextField txtImage;
    @FXML
    private TextField txtStock;

    private ProductDAO productDAO = new ProductDAO();

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
        colStock.setCellValueFactory(new PropertyValueFactory<>("stock"));

        addDeleteButton();
        loadProducts();

        tableProducts.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                populateFields(newSelection);
            }
        });
    }

    private void loadProducts() {
        ObservableList<Product> data = FXCollections.observableArrayList(productDAO.getAll());
        tableProducts.setItems(data);
    }

    private void populateFields(Product p) {
        txtName.setText(p.getName());
        txtPrice.setText(String.valueOf(p.getPrice()));
        txtDescription.setText(p.getDescription());
        txtImage.setText(p.getImage());
        txtStock.setText(String.valueOf(p.getStock()));
    }

    @FXML
    public void onAdd() {
        try {
            String name = txtName.getText();
            double price = Double.parseDouble(txtPrice.getText());
            String desc = txtDescription.getText();
            String img = txtImage.getText();
            int stock = Integer.parseInt(txtStock.getText());

            Product p = new Product();
            p.setName(name);
            p.setPrice(price);
            p.setDescription(desc);
            p.setImage(img);
            p.setStock(stock);

            productDAO.save(p);
            loadProducts();
            clearFields();
        } catch (NumberFormatException e) {
            showAlert("Error", "Invalid number format for Price or Stock.");
        }
    }

    @FXML
    public void onUpdate() {
        Product selected = tableProducts.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Error", "No product selected.");
            return;
        }

        try {
            selected.setName(txtName.getText());
            selected.setPrice(Double.parseDouble(txtPrice.getText()));
            selected.setDescription(txtDescription.getText());
            selected.setImage(txtImage.getText());
            selected.setStock(Integer.parseInt(txtStock.getText()));

            productDAO.update(selected);
            loadProducts();
            clearFields();
        } catch (NumberFormatException e) {
            showAlert("Error", "Invalid number format for Price or Stock.");
        }
    }

    @FXML
    public void onBack() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(
                getClass().getResource("/com/emsi/onsp/onligne_shopping/admin_dashboard.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) tableProducts.getScene().getWindow();
        stage.setScene(scene);
    }

    private void addDeleteButton() {
        Callback<TableColumn<Product, Void>, TableCell<Product, Void>> cellFactory = new Callback<>() {
            @Override
            public TableCell<Product, Void> call(final TableColumn<Product, Void> param) {
                return new TableCell<>() {
                    private final Button btn = new Button("Delete");

                    {
                        btn.getStyleClass().add("button-danger");
                        btn.setOnAction((event) -> {
                            Product data = getTableView().getItems().get(getIndex());
                            productDAO.delete(data);
                            loadProducts();
                        });
                    }

                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(btn);
                        }
                    }
                };
            }
        };
        colAction.setCellFactory(cellFactory);
    }

    private void clearFields() {
        txtName.clear();
        txtPrice.clear();
        txtDescription.clear();
        txtImage.clear();
        txtStock.clear();
        tableProducts.getSelectionModel().clearSelection();
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
