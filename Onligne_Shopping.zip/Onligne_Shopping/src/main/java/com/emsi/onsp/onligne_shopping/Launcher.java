package com.emsi.onsp.onligne_shopping;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(ShoppingApplication.class, args);
    }
}
