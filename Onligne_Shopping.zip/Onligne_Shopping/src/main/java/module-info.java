module com.emsi.onsp.onligne_shopping {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;
    requires java.sql;
    requires java.naming;
    requires jakarta.persistence;
    requires org.hibernate.orm.core;

    requires javafx.swing;
    requires javafx.media;
    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires net.synedra.validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires eu.hansolo.tilesfx;
    requires com.almasb.fxgl.all;

    opens com.emsi.onsp.onligne_shopping to javafx.fxml;

    exports com.emsi.onsp.onligne_shopping;

    exports com.emsi.onsp.onligne_shopping.controller;

    opens com.emsi.onsp.onligne_shopping.controller to javafx.fxml;

    exports com.emsi.onsp.onligne_shopping.config;

    opens com.emsi.onsp.onligne_shopping.config to org.hibernate.orm.core;

    exports com.emsi.onsp.onligne_shopping.dao;

    opens com.emsi.onsp.onligne_shopping.dao to org.hibernate.orm.core;

    exports com.emsi.onsp.onligne_shopping.model;

    opens com.emsi.onsp.onligne_shopping.model to javafx.base, org.hibernate.orm.core;

    exports com.emsi.onsp.onligne_shopping.utils;

    opens com.emsi.onsp.onligne_shopping.utils to org.hibernate.orm.core;
}