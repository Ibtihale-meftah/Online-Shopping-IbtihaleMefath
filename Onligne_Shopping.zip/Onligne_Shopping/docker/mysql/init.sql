CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100),
 email VARCHAR(100),
 password VARCHAR(255),
 role VARCHAR(20) DEFAULT 'CLIENT'
);

CREATE TABLE IF NOT EXISTS real_estate_products (
 id INT AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(255),
 type VARCHAR(50),
 city VARCHAR(100),
 address VARCHAR(255),
 surface_m2 INT,
 rooms INT,
 price DOUBLE,
 status VARCHAR(50),
 description TEXT,
 image VARCHAR(255)
);

INSERT INTO users (name, email, password, role) VALUES
                                                    ('Admin', 'admin@shop.com', 'admin123', 'ADMIN'),
                                                    ('Client', 'client@shop.com', 'client123', 'CLIENT');

INSERT INTO real_estate_products (title, type, city, address, surface_m2, rooms, price, status, description, image) VALUES
('Luxury Villa', 'Villa', 'Marrakech', 'Palm Grove', 450, 6, 5000000, 'Available', 'Beautiful villa with pool', 'villa.png'),
('Modern Apartment', 'Apartment', 'Casablanca', 'Maarif', 120, 3, 1500000, 'Available', 'Central apartment', 'apt.png'),
('Cozy Studio', 'Studio', 'Rabat', 'Agdal', 45, 1, 600000, 'Rented', 'Student studio', 'studio.png');


CREATE TABLE IF NOT EXISTS orders (
                                      id INT AUTO_INCREMENT PRIMARY KEY,
                                      order_date DATETIME,
                                      total DOUBLE,
                                      user_id INT,
                                      FOREIGN KEY (user_id) REFERENCES users(id)
    );

CREATE TABLE IF NOT EXISTS order_items (
                                           id INT AUTO_INCREMENT PRIMARY KEY,
                                           order_id INT,
                                           product_id INT,
                                           quantity INT,
                                           price DOUBLE,
                                           FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES real_estate_products(id)
    );

